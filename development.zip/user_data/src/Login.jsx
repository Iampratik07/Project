import React, {useState} from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import axios from 'axios'
import { toast } from 'react-toastify';

export default function Login() {

  const redirect = useNavigate();
  const [formdata, setFormvalue] =  useState({
    email: "",
    password: "",
  })

  const onchange = (e) => {
    setFormvalue({ ...formdata, [e.target.name]: e.target.value });
  }

  const validation = () => {
    const result = true;
    if (formdata.email == "" || formdata.email == null) {
      result = false;
      toast.error('email field is required !');
      return false;
    }

    if (formdata.password == "" || formdata.password == null) {
      result = false;
      toast.error('password field is required !');
      return false;
    }
    return result;
  }

  const onsubmit =  async (e) => {
    e.preventDefault();
    if (validation()) {
      await axios.get(` http://localhost:3000/user?email=${formdata.email}`)
      .then((res) => {
        if (res.data.length > 0) {
          if (res.data[0].password == formdata.password) {
            localStorage.setItem('id', res.data[0].id);
            localStorage.setItem('name', res.data[0].name);

            toast.success('Login Successfull !');
            return redirect('/');
          }
          else {
            toast.error('Password Not Match !');
            return false;
          }
        }
        else {
          toast.error('Email Not Match !');
          return false;
        }
      })
      
    }
  }
  return (
    <div>
      <form className="col-md-5 m-auto" method="post" role="form">
        <h1 classname="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">Log in</h1>
        <div className="mb-3 mt-4">
          <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
          <input type="email" className="form-control" value={formdata.email} onChange={onchange} id="email" name="email" placeholder="Email" />
        </div>
        <div className="mb-3">
          <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
          <input type="password" name='password' className="form-control" value={formdata.password} onChange={onchange} placeholder="password" id="password" />
        </div>
        <button type="submit" onClick={onsubmit} className="btn btn-primary">Log In</button>
        <div className="col text-end mt-2">
          <NavLink to="/Signup" >Click Here for Signup</NavLink>
        </div>
      </form>
    </div>

  )
}


