import { BrowserRouter, Route, Routes } from "react-router-dom";
import Dashboard from "./Dashboard";
import Login from "./Login";
import Add_Data from "./Add_Data";
import Edit_Data from "./Edit_Data";
import Signup from "./Signup";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
 

function App() {
  return (
    <>
    <BrowserRouter>
      <Routes>
        <Route path="/" index element={<><Dashboard/><Add_Data/></>}></Route>
        <Route path="/Login" index element={<><Dashboard/><Login/></>}></Route>
        <Route path="/Add_Data" index element={<><Dashboard/><Add_Data/></>}></Route>
        <Route path="/Edit_Data/:id" index element={<><Dashboard/><Edit_Data/></>}></Route>
        <Route path="/Signup" index element={<><Dashboard/><Signup/></>}></Route>
      </Routes>
      <ToastContainer/>
    </BrowserRouter>
    </>

  );
}

export default App;
