import React, { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios'
import { toast } from 'react-toastify';


export default function Edit_Data() {

  const [formdata, setformdata] = useState({
    name: "",
    contact: "",
    email: "",
    password: ""
  })

  const redirect = useNavigate()
  const { id } = useParams()
  //For Fatch Particular Users Data

  useEffect(() => {
    fatch()
  }, [])


  const fatch = async () => {
    const res = await axios.get(`http://localhost:3000/user/${id}`)
    setformdata(res.data)
  }

  const onchange = (e) => {
    setformdata({ ...formdata, [e.target.name]: e.target.value })
  }

  const onsubmit = async (e) => {
    e.preventDefault()
    await axios.patch(`http://localhost:3000/user/${id}`, formdata)
      .then((res) => {
        if (res.status == 200) {
          toast.success("Update Success !")
          redirect("/Add_Data")
        }
      })
  }
  return (
    <div>
      <form className="col-md-5 m-auto" method="post" role="form">
        <div className="mb-3">
          <h1 classname="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">Edit Data</h1>
          <label htmlFor="exampleInp" className="form-label">Name</label>
          <input type="text" value={formdata.name} onChange={onchange} className="form-control" id="name" name="name" placeholder="Name" />
        </div>
        <div className="mb-3">
          <label htmlFor="exampleInputEmail1" className="form-label">Contact</label>
          <input type="number" value={formdata.contact} onChange={onchange} className="form-control" id="contact" placeholder="contact" name="contact" />
        </div>
        <div className="mb-3">
          <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
          <input type="email" value={formdata.email} onChange={onchange} className="form-control" id="email" name="email" placeholder="Email" />
        </div>
        <div className="mb-3">
          <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
          <input type="password" value={formdata.password} onChange={onchange} name='password' className="form-control" placeholder="password" id="password" />
        </div>
        <button type="submit" onClick={onsubmit} className="btn btn-primary">Save Data</button>
      </form>
    </div>
  )
}


