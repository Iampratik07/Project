import React, { useState, useEffect } from 'react'
import axios from 'axios';
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'



export default function Add_Data() {
  const redirect = useNavigate()

  const [data, setdata] = useState()
  useEffect(() => {
    fatch()
  }, [])

  const fatch = async () => {
    const res = await axios.get(`http://localhost:3000/user`)
    setdata(res.data);
  }
  //delete data

  const ondelete = async (id) => {
    if (window.confirm("Are you sure to remove user ?")) {
      await axios.delete(`http://localhost:3000/user/${id}`)
      fatch()
      toast.success('Contact Delete Success !');
    }

  }

  return (
    <div>
      <section id="main-contact">
        <section className="wrapper">
          <h3><i className="fa fa-angle-right" />Add Data</h3>

          <div className='row mt'>
            <div className='col-md-12'>
              <div className='content-panel'>
                <table class="table caption-top">
                  <caption>List of users</caption>
                  <thead>
                    <tr>
                      <th>id</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>contact</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {
                      data && data.map((item) => {
                        return (
                          <tr>
                            <td style={{ paddingTop: 15 }}>{item.id}</td>
                            <td style={{ paddingTop: 15 }}>{item.name}</td>
                            <td style={{ paddingTop: 15 }}>{item.email}</td>
                            <td style={{ paddingTop: 15 }}>{item.contact}</td>
                            <td>
                              <button onClick={() => { redirect('/Edit_Data/' + item.id) }} className='btn btn-primary btn-xs' style={{ marginRight: 5 }}>Edit</button>
                              <button onClick={() => { ondelete(item.id) }} className='btn btn-danger btn-xs' style={{ marginLeft: 5 }}><i className='fa fa-trash-o' />Delete</button>
                            </td>
                          </tr>
                        )
                      })
                    }
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>
      </section>
    </div>
  )
}

