import React, { useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import axios from 'axios'
import { toast } from 'react-toastify';


export default function Signup() {
  const redirect = useNavigate()

  const [formdata, setFormvalue] = useState({
    id: "",
    name: "",
    email: "",
    password: "",
    contact: "",
  })

  const onchange = (e) => {
    setFormvalue({ ...formdata, [e.target.name]: e.target.value });
    //console.log(formvalue);
  }

  const validation = () => {
    const result = true;
    if (formdata.name == "" || formdata.name == null) {
      result = false;
      toast.error('Name field is required !');
      return false;
    }
    if (formdata.email == "" || formdata.email == null) {
      result = false;
      toast.error('email field is required !');
      return false;
    }
    if (formdata.password == "" || formdata.password == null) {
      result = false;
      toast.error('password field is required !');
      return false;
    }
    if (formdata.contact == "" || formdata.contact == null) {
      result = false;
      toast.error('mobile field is required !');
      return false;
    }
    return result;
  }


  const onsubmit = async (e) => {
    e.preventDefault();
    if (validation()) {
      await axios.post(`http://localhost:3000/user`, formdata)
        .then((res) => {
          //console.log(res);
          if (res.status === 201) {
            toast.success('Registeration Success');
           redirect("/Add_Data")
          }
        })
    }
  }
  return (
    <div>
      <form className="col-md-5 m-auto" method="post" role="form">
        <div className="mb-3">
          <h1 classname="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">Sign Up</h1>
          <label htmlFor="exampleInp" className="form-label">Name</label>
          <input type="text" value={formdata.name} onChange={onchange} className="form-control" id="name" name="name" placeholder="Name" />
        </div>
        <div className="mb-3">
          <label htmlFor="exampleInputEmail1" className="form-label">Contact</label>
          <input type="number" value={formdata.contact} onChange={onchange} className="form-control" id="contact" placeholder="mobile" name="contact" />
        </div>
        <div className="mb-3">
          <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
          <input type="email" value={formdata.email} onChange={onchange} className="form-control" id="email" name="email" placeholder="Email" />
        </div>
        <div className="mb-3">
          <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
          <input type="password" value={formdata.password} onChange={onchange} name='password' className="form-control" placeholder="password" id="password" />
        </div>
        <button type="submit" onClick={onsubmit} className="btn btn-primary">Sign Up</button>
        <div className="col text-end mt-2">
          <NavLink to="/login" >Click Here for Login</NavLink>
        </div>
      </form>
    </div>
  )

}

